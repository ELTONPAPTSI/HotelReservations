package hotelreservations;

import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class HotelReservations {

    private static ArrayList<Customer> customers = new ArrayList<>();
    private static ArrayList<Room> rooms = new ArrayList<>();
    private static ArrayList<Reservation> reservations = new ArrayList<>();

    private static final String CUSTOMERS_FILE = "customers.dat";
    private static final String ROOMS_FILE = "rooms.dat";
    private static final String RESERVATIONS_FILE = "reservations.dat";

    public static void main(String[] args) {
        // Φόρτωση δεδομένων από τα δυαδικά αρχεία κατά την εκκίνηση
        customers = DataManager.loadData(CUSTOMERS_FILE);
        rooms = DataManager.loadData(ROOMS_FILE);
        reservations = DataManager.loadData(RESERVATIONS_FILE);

        // Αν οι λίστες είναι άδειες (πρώτη φορά που τρέχει), βάζουμε μερικά δοκιμαστικά δωμάτια
        if (rooms.isEmpty()) {
            rooms.add(new Room(101, "Single", 50.0, true));
            rooms.add(new Room(102, "Double", 80.0, true));
            rooms.add(new Room(201, "Suite", 150.0, true));
        }

        Scanner scanner = new Scanner(System.in);
        int choice = 0;

        while (choice != 6) {
            System.out.println("\n=== ΣΥΣΤΗΜΑ ΚΡΑΤΗΣΕΩΝ ΞΕΝΟΔΟΧΕΙΟΥ ===");
            System.out.println("1. Καταχώρηση Νέου Πελάτη");
            System.out.println("2. Προβολή Λίστας Πελατών");
            System.out.println("3. Προβολή Διαθέσιμων Δωματίων");
            System.out.println("4. Δημιουργία Νέας Κράτησης");
            System.out.println("5. Προβολή Όλων των Κρατήσεων");
            System.out.println("6. Αποθήκευση & Έξοδος");
            System.out.print("Επιλέξτε μια ενέργεια (1-6): ");
            
            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                choice = 0;
            }

            switch (choice) {
                case 1:
                    addCustomer(scanner);
                    break;
                case 2:
                    viewCustomers();
                    break;
                case 3:
                    viewAvailableRooms();
                    break;
                case 4:
                    createReservation(scanner);
                    break;
                case 5:
                    viewReservations();
                    break;
                case 6:
                    // Αποθήκευση δεδομένων στα δυαδικά αρχεία πριν την έξοδο
                    DataManager.saveData(CUSTOMERS_FILE, customers);
                    DataManager.saveData(ROOMS_FILE, rooms);
                    DataManager.saveData(RESERVATIONS_FILE, reservations);
                    System.out.println("Ευχαριστούμε για τη χρήση! Αντίο.");
                    break;
                default:
                    System.out.println("Μη έγκυρη επιλογή. Παρακαλώ δοκιμάστε ξανά.");
            }
        }
        scanner.close();
    }

    private static void addCustomer(Scanner scanner) {
        System.out.println("\n--- Καταχώρηση Νέου Πελάτη ---");
        System.out.print("Όνομα: ");
        String firstName = scanner.nextLine();
        System.out.print("Επώνυμο: ");
        String lastName = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Τηλέφωνο: ");
        String phone = scanner.nextLine();

        int newId = customers.size() + 1;
        Customer customer = new Customer(newId, firstName, lastName, email, phone);
        customers.add(customer);
        System.out.println("Ο πελάτης καταχωρήθηκε επιτυχώς με ID: " + newId);
    }

    private static void viewCustomers() {
        System.out.println("\n--- Λίστα Πελατών ---");
        if (customers.isEmpty()) {
            System.out.println("Δεν υπάρχουν καταχωρημένοι πελάτες.");
            return;
        }
        for (Customer c : customers) {
            c.printDetails(); // Χρήση πολυμορφισμού
        }
    }

    private static void viewAvailableRooms() {
        System.out.println("\n--- Διαθέσιμα Δωμάτια ---");
        boolean found = false;
        for (Room r : rooms) {
            if (r.isAvailable()) {
                System.out.println("Δωμάτιο " + r.getRoomNumber() + " (" + r.getRoomType() + ") - Τιμή ανά νύχτα: " + r.getPricePerNight() + "€");
                found = true;
            }
        }
        if (!found) {
            System.out.println("Δεν υπάρχει κανένα διαθέσιμο δωμάτιο αυτή τη στιγμή.");
        }
    }

    private static void createReservation(Scanner scanner) {
        System.out.println("\n--- Δημιουργία Νέας Κράτησης ---");
        if (customers.isEmpty()) {
            System.out.println("Σφάλμα: Πρέπει πρώτα να καταχωρήσετε έναν πελάτη!");
            return;
        }
        
        viewCustomers();
        System.out.print("Επιλέξτε το ID του πελάτη: ");
        int customerId = Integer.parseInt(scanner.nextLine());
        
        Customer selectedCustomer = null;
        for (Customer c : customers) {
            if (c.getCustomerId() == customerId) {
                selectedCustomer = c;
                break;
            }
        }

        if (selectedCustomer == null) {
            System.out.println("Ο πελάτης δεν βρέθηκε.");
            return;
        }

        viewAvailableRooms();
        System.out.print("Επιλέξτε τον αριθμό του δωματίου: ");
        int roomNum = Integer.parseInt(scanner.nextLine());

        Room selectedRoom = null;
        for (Room r : rooms) {
            if (r.getRoomNumber() == roomNum && r.isAvailable()) {
                selectedRoom = r;
                break;
            }
        }

        if (selectedRoom == null) {
            System.out.println("Το δωμάτιο δεν είναι διαθέσιμο ή δεν υπάρχει.");
            return;
        }

        // Δημιουργία κράτησης για σήμερα (απλοποιημένο demo)
        int resId = reservations.size() + 1;
        Reservation reservation = new Reservation(resId, selectedCustomer, selectedRoom, new Date(), new Date());
        reservations.add(reservation);
        
        // Μαρκάρουμε το δωμάτιο ως μη διαθέσιμο
        selectedRoom.setAvailable(false);
        System.out.println("Η κράτηση δημιουργήθηκε επιτυχώς! ID Κράτησης: " + resId);
    }

    private static void viewReservations() {
        System.out.println("\n--- Λίστα Όλων των Κρατήσεων ---");
        if (reservations.isEmpty()) {
            System.out.println("Δεν υπάρχουν ενεργές κρατήσεις.");
            return;
        }
        for (Reservation res : reservations) {
            System.out.println("Κράτηση [" + res.getReservationId() + "] -> Πελάτης: " + 
                    res.getCustomer().getLastName() + " - Δωμάτιο: " + res.getRoom().getRoomNumber() + 
                    " (" + res.getRoom().getRoomType() + ")");
        }
    }
}