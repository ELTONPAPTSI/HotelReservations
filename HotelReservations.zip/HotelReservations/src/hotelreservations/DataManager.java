package hotelreservations;

import java.io.*;
import java.util.ArrayList;

public class DataManager {

    // Αποθήκευση Αντικειμένων σε Δυαδικό Αρχείο
    public static <T> void saveData(String filename, ArrayList<T> dataList) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(dataList);
            System.out.println("Τα δεδομένα αποθηκεύτηκαν επιτυχώς στο αρχείο: " + filename);
        } catch (IOException e) {
            System.out.println("Σφάλμα κατά την αποθήκευση στο αρχείο " + filename + ": " + e.getMessage());
        }
    }

    // Ανάκτηση Αντικειμένων από Δυαδικό Αρχείο
    @SuppressWarnings("unchecked")
    public static <T> ArrayList<T> loadData(String filename) {
        File file = new File(filename);
        if (!file.exists()) {
            return new ArrayList<>(); // Αν δεν υπάρχει το αρχείο, επέστρεψε κενή λίστα
        }
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            return (ArrayList<T>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Σφάλμα κατά την ανάγνωση από το αρχείο " + filename + ": " + e.getMessage());
            return new ArrayList<>();
        }
    }
}