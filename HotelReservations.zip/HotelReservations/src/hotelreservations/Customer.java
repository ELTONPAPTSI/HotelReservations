package hotelreservations;

public class Customer extends Person {
    private int customerId;
    private String email;

    public Customer(int customerId, String firstName, String lastName, String email, String phone) {
        super(firstName, lastName, phone);
        this.customerId = customerId;
        this.email = email;
    }

    public int getCustomerId() { return customerId; }
    public void setCustomerId(int customerId) { this.customerId = customerId; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    @Override
    public void printDetails() {
        System.out.println("Πελάτης [" + customerId + "]: " + getLastName() + " " + getFirstName() + " - Τηλ: " + getPhone());
    }
}
